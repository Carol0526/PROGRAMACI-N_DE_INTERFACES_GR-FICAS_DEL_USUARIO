
document.addEventListener('DOMContentLoaded', function() {
    const guardarBtn = document.getElementById('guardarBtn');
    const tarjetaForm = document.getElementById('tarjetaForm');
    const datosTablaBody = document.getElementById('datosTablaBody');

    guardarBtn.addEventListener('click', function(event) {
        event.preventDefault();

        const nombreTitular = document.getElementById('nombreTitular').value;
        const numeroTarjeta = document.getElementById('numeroTarjeta').value;
        const fechaVencimiento = document.getElementById('fechaVencimiento').value;
        const cvv = document.getElementById('cvv').value;
        let tipoTarjetaSeleccionado = '';
        document.querySelectorAll('input[name="tipo"]').forEach(input => {
            if (input.checked) {
                tipoTarjetaSeleccionado = input.value;
            }
        });
        const acepta = document.getElementById('acepta').checked ? 'Sí' : 'No';
        const tallaSeleccionada = document.getElementById('talla').value;
        const comentarios = document.getElementById('comentarios').value;

        if (nombreTitular && numeroTarjeta && fechaVencimiento && cvv && tipoTarjetaSeleccionado) {
            agregarFilaTabla(nombreTitular, numeroTarjeta, fechaVencimiento, cvv, tipoTarjetaSeleccionado, acepta, tallaSeleccionada, comentarios);
            tarjetaForm.reset();
        } else {
            alert('Por favor, complete los campos obligatorios (Nombre, Número de Tarjeta, Fecha de Vencimiento, CVV y Tipo de Tarjeta).');
        }
    });

    function agregarFilaTabla(nombre, numero, fecha, cvv, tipo, acepta, talla, comentarios) {
        const nuevaFila = datosTablaBody.insertRow();

        let celda = nuevaFila.insertCell();
        celda.textContent = nombre;

        celda = nuevaFila.insertCell();
        celda.textContent = numero;

        celda = nuevaFila.insertCell();
        celda.textContent = fecha;

        celda = nuevaFila.insertCell();
        celda.textContent = cvv;

        celda = nuevaFila.insertCell();
        celda.textContent = tipo;

        celda = nuevaFila.insertCell();
        celda.textContent = acepta;

        celda = nuevaFila.insertCell();
        celda.textContent = talla;

        celda = nuevaFila.insertCell();
        celda.textContent = comentarios;
    }
});
