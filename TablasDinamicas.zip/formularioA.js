document.addEventListener('DOMContentLoaded', function() {
    const guardarBtn = document.getElementById('guardarBtn');
    const nombreInput = document.getElementById('nombre');
    const apellidoInput = document.getElementById('apellido');
    const sexoInputs = document.querySelectorAll('input[name="tipo"]');
    const fechaNacInput = document.getElementById('fh_nac');
    const idRolSelect = document.getElementById('id_rol');
    const tablaAlumnosBody = document.getElementById('tablaAlumnos');
    const formulario = document.getElementById('alumnoForm');

    guardarBtn.addEventListener('click', function() {
        const nombre = nombreInput.value;
        const apellido = apellidoInput.value;
        let sexoSeleccionado = '';
        sexoInputs.forEach(input => {
            if (input.checked) {
                sexoSeleccionado = input.value;
            }
        });
        const fechaNac = fechaNacInput.value;
        const idRolTexto = idRolSelect.options[idRolSelect.selectedIndex].text;

        (nombre && apellido) && crearFilaTabla(nombre, apellido, sexoSeleccionado, fechaNac, idRolTexto);
        (nombre && apellido) || alert('Por favor, ingrese los datos');
    });

    function crearFilaTabla(nombre, apellido, sexo, fechaNac, rol) {
        const nuevaFila = tablaAlumnosBody.insertRow();

        const nombreCelda = nuevaFila.insertCell();
        nombreCelda.textContent = nombre;

        const apellidoCelda = nuevaFila.insertCell();
        apellidoCelda.textContent = apellido;

        const sexoCelda = nuevaFila.insertCell();
        sexoCelda.textContent = sexo;

        const fechaNacCelda = nuevaFila.insertCell();
        fechaNacCelda.textContent = fechaNac;

        const rolCelda = nuevaFila.insertCell();
        rolCelda.textContent = rol;

        formulario.reset(); 
    }
});